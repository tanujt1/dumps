
public class LoanTrustException extends Exception {

	private static final long serialVersionUID = 1L;

	public LoanTrustException(String msg) {
		super(msg);
	}

	public LoanTrustException(Throwable throwable) {
		super(throwable);
	}

	public LoanTrustException(String msg, Throwable throwable) {
		super(msg, throwable);
	}
}
