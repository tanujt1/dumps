import java.util.Date;

public class LoanTrustVo {
	private String policyNumber;
	private String panNumber;
	private Date startDate;
	private Integer period;
	

	private float loanRequestAmount;
	private float sumAssured;
	private Date endDate;
	private float accumulatedPremium;
	private float netPremiumAmount;
	@Override
	public String toString() {
		return "LoanTrustVo [policyNumber=" + policyNumber + ", panNumber=" + panNumber + ", startDate=" + startDate
				+ ", period=" + period + ", loanRequestAmount=" + loanRequestAmount + ", sumAssured=" + sumAssured
				+ ", endDate=" + endDate + ", accumulatedPremium=" + accumulatedPremium + ", netPremiumAmount="
				+ netPremiumAmount + "]";
	}
	public LoanTrustVo() {
		super();
		// TODO Auto-generated constructor stub
	}
	public LoanTrustVo(String policyNumber, String panNumber, Date startDate, Integer period, float loanRequestAmount,
			float sumAssured, Date endDate, float accumulatedPremium, float netPremiumAmount) {
		super();
		this.policyNumber = policyNumber;
		this.panNumber = panNumber;
		this.startDate = startDate;
		this.period = period;
		this.loanRequestAmount = loanRequestAmount;
		this.sumAssured = sumAssured;
		this.endDate = endDate;
		this.accumulatedPremium = accumulatedPremium;
		this.netPremiumAmount = netPremiumAmount;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + Float.floatToIntBits(accumulatedPremium);
		result = prime * result + ((endDate == null) ? 0 : endDate.hashCode());
		result = prime * result + Float.floatToIntBits(loanRequestAmount);
		result = prime * result + Float.floatToIntBits(netPremiumAmount);
		result = prime * result + ((panNumber == null) ? 0 : panNumber.hashCode());
		result = prime * result + ((period == null) ? 0 : period.hashCode());
		result = prime * result + ((policyNumber == null) ? 0 : policyNumber.hashCode());
		result = prime * result + ((startDate == null) ? 0 : startDate.hashCode());
		result = prime * result + Float.floatToIntBits(sumAssured);
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		LoanTrustVo other = (LoanTrustVo) obj;
		if (Float.floatToIntBits(accumulatedPremium) != Float.floatToIntBits(other.accumulatedPremium))
			return false;
		if (endDate == null) {
			if (other.endDate != null)
				return false;
		} else if (!endDate.equals(other.endDate))
			return false;
		if (Float.floatToIntBits(loanRequestAmount) != Float.floatToIntBits(other.loanRequestAmount))
			return false;
		if (Float.floatToIntBits(netPremiumAmount) != Float.floatToIntBits(other.netPremiumAmount))
			return false;
		if (panNumber == null) {
			if (other.panNumber != null)
				return false;
		} else if (!panNumber.equals(other.panNumber))
			return false;
		if (period == null) {
			if (other.period != null)
				return false;
		} else if (!period.equals(other.period))
			return false;
		if (policyNumber == null) {
			if (other.policyNumber != null)
				return false;
		} else if (!policyNumber.equals(other.policyNumber))
			return false;
		if (startDate == null) {
			if (other.startDate != null)
				return false;
		} else if (!startDate.equals(other.startDate))
			return false;
		if (Float.floatToIntBits(sumAssured) != Float.floatToIntBits(other.sumAssured))
			return false;
		return true;
	}
	public String getPolicyNumber() {
		return policyNumber;
	}
	public void setPolicyNumber(String policyNumber) {
		this.policyNumber = policyNumber;
	}
	public String getPanNumber() {
		return panNumber;
	}
	public void setPanNumber(String panNumber) {
		this.panNumber = panNumber;
	}
	public Date getStartDate() {
		return startDate;
	}
	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}
	public Integer getPeriod() {
		return period;
	}
	public void setPeriod(Integer period) {
		this.period = period;
	}
	public float getLoanRequestAmount() {
		return loanRequestAmount;
	}
	public void setLoanRequestAmount(float loanRequestAmount) {
		this.loanRequestAmount = loanRequestAmount;
	}
	public float getSumAssured() {
		return sumAssured;
	}
	public void setSumAssured(float sumAssured) {
		this.sumAssured = sumAssured;
	}
	public Date getEndDate() {
		return endDate;
	}
	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}
	public float getAccumulatedPremium() {
		return accumulatedPremium;
	}
	public void setAccumulatedPremium(float accumulatedPremium) {
		this.accumulatedPremium = accumulatedPremium;
	}
	public float getNetPremiumAmount() {
		return netPremiumAmount;
	}
	public void setNetPremiumAmount(float netPremiumAmount) {
		this.netPremiumAmount = netPremiumAmount;
	}
	

}
