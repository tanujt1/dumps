
public class CreditCardValidationException extends Exception {
	CreditCardValidationException(String str) {
		super(str);
	}
}
