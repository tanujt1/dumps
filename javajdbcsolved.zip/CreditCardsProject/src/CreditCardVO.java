import java.util.Date;

public class CreditCardVO {
	private String creditCardNumber;
	private String customerName;
	private int billAmount;
	private Date dueDate;
	private Date paymentDate;
	private double fine;
	private String grade;

	public String getCreditCardNumber() {
		return creditCardNumber;
	}

	public void setCreditCardNumber(String creditCardNumber) {
		this.creditCardNumber = creditCardNumber;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public int getBillAmount() {
		return billAmount;
	}

	public void setBillAmount(int billAmount) {
		this.billAmount = billAmount;
	}

	public Date getDueDate() {
		return dueDate;
	}

	public void setDueDate(Date dueDate) {
		this.dueDate = dueDate;
	}

	public Date getPaymentDate() {
		return paymentDate;
	}

	public void setPaymentDate(Date paymentDate) {
		this.paymentDate = paymentDate;
	}

	public double getFine() {
		return fine;
	}

	public void setFine(double fine) {
		this.fine = fine;
	}

	public String getGrade() {
		return grade;
	}

	public void setGrade(String grade) {
		this.grade = grade;
	}

	@Override
	public String toString() {
		return "CreditCardVO [creditCardNumber=" + creditCardNumber
				+ ", customerName=" + customerName + ", billAmount="
				+ billAmount + ", dueDate=" + dueDate + ", paymentDate="
				+ paymentDate + ", fine=" + fine + ", grade=" + grade + "]";
	}
}

