import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class CardDetail {
	public static void main(String[] args) {
		CardDetail cardDetail = new CardDetail();
		try {
			System.out.println(cardDetail.calculateCardFineDetails("cardinput.txt"));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public Map calculateCardFineDetails(String fileName) throws CreditCardValidationException {
		Map<Integer, Map<String, CreditCardVO>> map = new HashMap<Integer, Map<String, CreditCardVO>>();
		File file = new File(fileName);
		if (!file.exists()) {
			throw new CreditCardValidationException("Invalid file path");
		}
		try {
			BufferedReader br = new BufferedReader(new FileReader(file));
			Map<String, CreditCardVO> visaMap = new HashMap<String, CreditCardVO>();
			Map<String, CreditCardVO> amexMap = new HashMap<String, CreditCardVO>();
			List<CreditCardVO> visaList = new ArrayList<CreditCardVO>();
			List<CreditCardVO> amexList = new ArrayList<CreditCardVO>();
			String line = null;
			while ((line = br.readLine()) != null) {
				CreditCardVO cardVO = new CreditCardVO();
				String[] strArr = line.split("\\|");
				cardVO.setCustomerName(strArr[1]);
				cardVO.setBillAmount(Integer.parseInt(strArr[2]));
				String creditCardNo = strArr[0];
				SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
				sdf.setLenient(false);
				try {
					Date dueDate = sdf.parse(strArr[3]);
					cardVO.setDueDate(dueDate);
					Date paymentDate = sdf.parse(strArr[4]);
					cardVO.setPaymentDate(paymentDate);

				} catch (ParseException e) {
					throw new CreditCardValidationException(
							"invalid date format");
				}
				if (creditCardNo.matches("[4][0-9]{15}")) {
					cardVO.setCreditCardNumber(creditCardNo);
					visaList.add(cardVO);
				} else if (creditCardNo.matches("(34|35)[0-9]{13}")) {
					cardVO.setCreditCardNumber(creditCardNo);
					amexList.add(cardVO);
				} else {
					throw new CreditCardValidationException(
							"invalid credit card number");
				}
			}

			for (CreditCardVO cardVO : visaList) {
				if (cardVO.getPaymentDate().getTime() < cardVO.getDueDate()
						.getTime()) {
					cardVO.setGrade("A");
				} else {
					cardVO.setGrade("B");
					long diff = (cardVO.getPaymentDate().getTime() - cardVO
							.getDueDate().getTime());
					int days = (int) (diff / (1000 * 60 * 60 * 24));
					if (days <= 5) {
						cardVO.setFine(cardVO.getBillAmount() * 0.1);
					} else {
						cardVO.setFine(cardVO.getBillAmount() * 0.2);
					}

				}
				removeDuplicates(visaMap, cardVO);
			}
			for (CreditCardVO cardVO : amexList) {
				if (cardVO.getPaymentDate().getTime() < cardVO.getDueDate()
						.getTime()) {
					cardVO.setGrade("A");
				} else {
					cardVO.setGrade("B");
					long diff = (cardVO.getPaymentDate().getTime() - cardVO
							.getDueDate().getTime());
					int days = (int) (diff / (1000 * 60 * 60 * 24));
					if (days <= 5) {
						cardVO.setFine(cardVO.getBillAmount() * 0.1);
					} else {
						if (cardVO.getBillAmount() < 15000)
							cardVO.setFine(cardVO.getBillAmount() * 0.2);
						else
							cardVO.setFine(cardVO.getBillAmount() * 0.3);
					}

				}
				removeDuplicates(amexMap, cardVO);
			}
			map.put(1, visaMap);
			map.put(2, amexMap);

		} catch (Exception e) {
			throw new CreditCardValidationException(e.getMessage());
		}
		return map;
	}

	private void removeDuplicates(Map<String, CreditCardVO> map,CreditCardVO cardVO) {
		if (map.containsKey(cardVO.getCreditCardNumber())) {
			if (map.get(cardVO.getCreditCardNumber()).getPaymentDate()
					.getTime() < cardVO.getPaymentDate().getTime()) {
				map.put(cardVO.getCreditCardNumber(), cardVO);
			}
		} else {
			map.put(cardVO.getCreditCardNumber(), cardVO);
		}
	}
}

