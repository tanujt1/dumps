
public class PatientInformationDetailsException extends Exception {
	PatientInformationDetailsException(String msg){
		super(msg);
	}

}
