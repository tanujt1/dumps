import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class PatientInformationTool {
	public static void main(String[] args) {
		String filePath = "hosp.txt";
		PatientInformationTool pit = new PatientInformationTool();
		 
		try{
			System.out.println(pit.getPatientDetails(filePath));
		}
		catch(Exception e){
			e.printStackTrace();
		}
		
	}
     
 public Map<Integer, Map> getPatientDetails(String filepath) throws PatientInformationDetailsException{
	Map<Integer,Map> finalMap  = new HashMap<>();
	 Map<String,List<PatientVO>> innerMap1 = new HashMap<>();
	// Map<String,List<PatientVO>> innerMap3 = new HashMap<>();
	 Map<String,Integer> innerMap2 = new HashMap<>();
	 //List<PatientVO> pList1 = new ArrayList<>();
	 List<PatientVO> pList2 = new ArrayList<>();
	 Set<Date> allDate = new HashSet<>();
	 List<Date> dList  = new ArrayList<>();
	
	 File file = new File(filepath);
	 String line = null;
	 String str[] = null;
	 int genCount = 0;
	 int neuCount = 0;
	 int entCount = 0;
	 
	 try{
	 BufferedReader br = new BufferedReader(new FileReader(file));
	 while((line = br.readLine()) != null){
		 PatientVO pvo = new PatientVO();
		 str = line.split(";");
		 if(str.length != 6){
			 throw new PatientInformationDetailsException("All fields are mandatory");
		 }
		 for(String arr:str){
			 if(arr.isEmpty() || arr.equals(null)){
				 throw new PatientInformationDetailsException("Fields cannot be null");
			 }
			 
		 }
		 if(str[0].matches("[ A-Za-z]+")){
			 pvo.setPatientName(str[0]);
			 //System.out.println(pvo.getPatientName());
		 }
		 else{
			 throw new PatientInformationDetailsException("Name should contain only alphabets and spaces");
		 }
		 SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
		 sdf.setLenient(false);
		 try {
				Date admissDate = sdf.parse(str[4]);
				allDate.add(admissDate);
				pvo.setAdmnDate(admissDate);
				Date dischDate = sdf.parse(str[5]);
				pvo.setDischDate(dischDate);

			} catch (ParseException e) {
				throw new PatientInformationDetailsException(
						"invalid date format");
			}
		 Calendar admn  = Calendar.getInstance();
		 Calendar disch  = Calendar.getInstance();
		 pvo.setGender(str[2]);
		 admn.setTime(pvo.getAdmnDate());
		 disch.setTime(pvo.getDischDate());
		 if(admn.after(disch)){
			 throw new PatientInformationDetailsException("Admission Date cannot be greater than discharge date");
		 }
		// System.out.println(admn.getTime());
		 if(str[1].matches("(IN|OUT)[0-9]+")){
			 pvo.setMrn(str[1]);
			 //System.out.println(pvo.getMrn());
		 }
		 else{
			 throw new PatientInformationDetailsException("MRN is Invalid");
		 }
		 if(str[3].matches("[0-9]{4}+[-](GEN|NEU|ENT)")){
			 pvo.setPhysID(str[3]);
			 //System.out.println(pvo.getPhysID());
			// System.out.println(pvo);
		 }
		 else{
			 throw new PatientInformationDetailsException("Physician Id is not in appt format");
		 }
		 
		 long diff = Math.abs( pvo.getDischDate().getTime() - pvo.getAdmnDate().getTime());
		 long noofdays = (diff/(1000*24*60*60));
		 int billamt = 0;
		
		 //System.out.println(noofdays);
		 String cat[] = pvo.getPhysID().split("-");
		 if(cat[1].equals("GEN")){
			 billamt = (int) (noofdays *1250);
			 pvo.setBill(billamt);
			 genCount++;
			 innerMap2.put("GEN", genCount);
		 }
		 if(cat[1].equals("NEU")){
			 billamt = (int) (noofdays * 1500);
			 pvo.setBill(billamt);
			 neuCount++;
			 innerMap2.put("NEU", neuCount);
		 }
		 if(cat[1].equals("ENT")){
			 billamt = (int) (noofdays * 1750);
			 pvo.setBill(billamt);
			 entCount++;
			 innerMap2.put("ENT", entCount);
		 }
		

			pList2.add(pvo);
			
			//System.out.println(pList2);
			/*for(PatientVO pv:pList2){
				if(pv.getAdmnDate().equals(str[4])){
					innerMap1.put(str[4], pList2);
				}*/
			}
	 dList.addAll(allDate);
	// System.out.println(pList2);
	 DateFormat df = new SimpleDateFormat("dd/MM/yyyy");
	 for(Date dl:dList)
	    {
	    	 ArrayList<PatientVO> inner=new ArrayList<PatientVO>();
	    	for(PatientVO al:pList2)
	    	{
	    		if(dl.equals(al.getAdmnDate()))
	    		{ 
	    		    inner.add(al);
	    		}
	    	}
	    	innerMap1.put(df.format(dl), inner);
	    }
	    
	
	 

	 
	 
	 finalMap.put(1, innerMap1);
	 finalMap.put(2, innerMap2);
	 
 }
	 catch(Exception e){
		 e.printStackTrace();
	 }
	return finalMap;
 
 }
}	 
	
	

