import java.util.Date;

public class PatientVO {
private String patientName;
private String mrn;
private String gender;
private String physID;
private Date admnDate;
private int Bill;
public PatientVO() {
	super();
	// TODO Auto-generated constructor stub
}
public PatientVO(String patientName, String mrn, String gender, String physID, Date admnDate, int bill,
		Date dischDate) {
	super();
	this.patientName = patientName;
	this.mrn = mrn;
	this.gender = gender;
	this.physID = physID;
	this.admnDate = admnDate;
	Bill = bill;
	this.dischDate = dischDate;
}
public int getBill() {
	return Bill;
}
public void setBill(int bill) {
	Bill = bill;
}
Date dischDate;
public String getPatientName() {
	return patientName;
}
public void setPatientName(String patientName) {
	this.patientName = patientName;
}
public String getMrn() {
	return mrn;
}
public PatientVO(String patientName, String mrn, String gender, String physID, Date admnDate, Date dischDate) {
	super();
	this.patientName = patientName;
	this.mrn = mrn;
	this.gender = gender;
	this.physID = physID;
	this.admnDate = admnDate;
	this.dischDate = dischDate;
}
@Override
public String toString() {
	return "PatientVO [patientName=" + patientName + ", mrn=" + mrn + ", gender=" + gender + ", physID=" + physID
			+ ", admnDate=" + admnDate + ", Bill=" + Bill + ", dischDate=" + dischDate + "]";
}
@Override
public int hashCode() {
	final int prime = 31;
	int result = 1;
	result = prime * result + Bill;
	result = prime * result + ((admnDate == null) ? 0 : admnDate.hashCode());
	result = prime * result + ((dischDate == null) ? 0 : dischDate.hashCode());
	result = prime * result + ((gender == null) ? 0 : gender.hashCode());
	result = prime * result + ((mrn == null) ? 0 : mrn.hashCode());
	result = prime * result + ((patientName == null) ? 0 : patientName.hashCode());
	result = prime * result + ((physID == null) ? 0 : physID.hashCode());
	return result;
}
@Override
public boolean equals(Object obj) {
	if (this == obj)
		return true;
	if (obj == null)
		return false;
	if (getClass() != obj.getClass())
		return false;
	PatientVO other = (PatientVO) obj;
	if (Bill != other.Bill)
		return false;
	if (admnDate == null) {
		if (other.admnDate != null)
			return false;
	} else if (!admnDate.equals(other.admnDate))
		return false;
	if (dischDate == null) {
		if (other.dischDate != null)
			return false;
	} else if (!dischDate.equals(other.dischDate))
		return false;
	if (gender == null) {
		if (other.gender != null)
			return false;
	} else if (!gender.equals(other.gender))
		return false;
	if (mrn == null) {
		if (other.mrn != null)
			return false;
	} else if (!mrn.equals(other.mrn))
		return false;
	if (patientName == null) {
		if (other.patientName != null)
			return false;
	} else if (!patientName.equals(other.patientName))
		return false;
	if (physID == null) {
		if (other.physID != null)
			return false;
	} else if (!physID.equals(other.physID))
		return false;
	return true;
}
public void setMrn(String mrn) {
	this.mrn = mrn;
}
public String getGender() {
	return gender;
}
public void setGender(String gender) {
	this.gender = gender;
}
public String getPhysID() {
	return physID;
}
public void setPhysID(String physID) {
	this.physID = physID;
}
public Date getAdmnDate() {
	return admnDate;
}
public void setAdmnDate(Date admnDate) {
	this.admnDate = admnDate;
}
public Date getDischDate() {
	return dischDate;
}
public void setDischDate(Date dischDate) {
	this.dischDate = dischDate;
}
}
